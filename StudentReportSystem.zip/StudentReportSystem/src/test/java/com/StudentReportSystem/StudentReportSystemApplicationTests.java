package com.StudentReportSystem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StudentReportSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
