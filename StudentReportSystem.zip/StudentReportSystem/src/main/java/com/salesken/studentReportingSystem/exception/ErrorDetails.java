package com.salesken.studentReportingSystem.exception;

import java.time.LocalDateTime;

import org.apache.http.HttpStatus;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ErrorDetails {

	private LocalDateTime timeStamp;
	private String message;
	private HttpStatus httpStatus;
	private String details;
	public void setTimeStamp(LocalDateTime now) {
		// TODO Auto-generated method stub
		this.timeStamp=now;
		
	}
	public void setMessage(String message2) {
		// TODO Auto-generated method stub
		this.message=message2;
	}
	public void setDetails(String description) {
		// TODO Auto-generated method stub
		this.details=description;
	}
}
